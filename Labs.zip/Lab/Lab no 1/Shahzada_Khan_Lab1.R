#1
vehicles_vehicledata <- read.csv("Vehicle.csv")
summary(vehicles_vehicledata)

#2
#Structure of the dataset
str(vehicles_vehicledata)
#dimension
dim(vehicles_vehicledata)

#3
# show name of the column
colnames(vehicles_vehicledata)
#show starting 3 rows
head(vehicles_vehicledata, n = 3)
#show last 6 rows
tail(vehicles_vehicledata, n = 6)

#4
#Calculate average kilometers Driven for each type of Car
average_kilometers <- aggregate(Kms_Driven ~ Car_Name, data = vehicles_vehicledata, FUN = mean)
#Print the result 
print(average_kilometers)

#5
#Calculate average Sell Price in each year
average_sell_price <- aggregate(Selling_Price ~ Year, data = vehicles_vehicledata, FUN = mean)
#Output 
print(average_sell_price)

#6
#Select the relevant columns
cols <- c("Car_Name", "Fuel_Type", "Seller_Type", "Transmission")
#Get the individual combinations
individual_combinations <- unique(vehicles_vehicledata)
#print the result
print(individual_combinations)

#7
# Selecting the relevant columns
cols <- c("Car_Name", "Fuel_Type", "Seller_Type", "Transmission")
# Getting the combinations and their frequencies
combinations <- table(vehicles_vehicledata[, cols])
# Sort combinations in ascending order of frequency
Data_ascending <- combinations[order(combinations)]
# Sort combinations in descending order of frequency
Data_descending <- combinations[order(combinations, decreasing = TRUE)]
# Print combinations and their frequencies in ascending order
print(Data_ascending)
# Print combinations and their frequencies in descending order
print(Data_descending)

#8
# Check for missing values
Missing_val <- sum(is.na(vehicles_vehicledata))
# Print the result
if (Missing_val > 0) {
  print(paste("There are", Missing_val, "missing values in the dataset."))
} else {
  print("No missing values in the dataset.")
}

#9
# Check for missing values in each column
Missing_Val_per_column <- colSums(is.na(vehicles_vehicledata))

# Identify columns with missing values
col_with_missing_val <- names(Missing_Val_per_column)[Missing_Val_per_column > 0]

# Print columns with missing values
print("Missing Column Values:")
print(col_with_missing_val)

# Print total missing values for each column
print("Total missing values per column:")
print(Missing_Val_per_column[col_with_missing_val])

#10
# Function to calculate the mode
Mode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}

# Replace missing values with mode
replacing_data <- data.frame(lapply(vehicles_vehicledata, function(x) replace(x, is.na(x), Mode(x))))

# Check if missing values were replaced successfully
missing_values_replaced <- colSums(is.na(vehicles_vehicledata))

# Print the result
if (sum(missing_values_replaced) == 0) {
  print("Successfully Replaced Missing Values.")
} else {
  print("Few Missing Values not replaced.")
}

#11
# Check for duplicate rows
Duplicate_Rows <- duplicated(vehicles_vehicledata)

# Print the number of duplicate rows
print(paste("Number of duplicate rows:", sum(Duplicate_Rows)))

# Remove duplicate rows
data_cleaned <- unique(vehicles_vehicledata[!Duplicate_Rows, ])

# Print the number of remaining rows after removing duplicates
print(paste("Number of remaining rows after removing duplicates:", nrow(data_cleaned)))


#12
# Original attribute values
Fuel_Type <- c("Petrol", "Diesel", "CNG")
Seller_Type <- c("Dealer", "Individual")
Transmission_Type <- c("Manual", "Automatic")

# Conversion mappings
mapping_fuel_type <- c("Petrol" = 0, "Diesel" = 1, "CNG" = 2)
mapping_seller_type <- c("Dealer" = 0, "Individual" = 1)
mapping_transmission <- c("Manual" = 0, "Automatic" = 1)

# Convert attribute values
fuel_type_converted <- mapping_fuel_type[Fuel_Type]
seller_type_converted <- mapping_seller_type[Seller_Type]
transmission_converted <- mapping_transmission[Transmission]

# Print the conversion outputs
print(fuel_type_converted)
print(seller_type_converted)
print(transmission_converted)

#13
# Calculate the current year
Current_year <- as.numeric(format(Sys.Date(), "%Y"))
# Add a new field 'Age' based on the 'Year' column
vehicles_vehicledata <- transform(vehicles_vehicledata, Age = Current_year - Year)
# Show the updated dataset with the 'Age' field
print(vehicles_vehicledata)

#14
# Selecting specific columns
new_dataset <- vehicles_vehicledata[c("Car_Name", "Selling_Price", "Present_Price", "Kms_Driven")]

# Show the output of the new dataset
print(new_dataset)



# Load the dplyr package for data manipulation
library(dplyr)

# Define the conversion mappings
fuel_type_conversion <- c("Petrol" = 0, "Diesel" = 1, "CNG" = 2)
seller_type_conversion <- c("Dealer" = 0, "Individual" = 1)
transmission_conversion <- c("Manual" = 0, "Automatic" = 1)

# Perform the attribute value replacements
converted_data <- vehicle_data %>%
  mutate(Fuel_Type = ifelse(Fuel_Type %in% names(fuel_type_conversion), fuel_type_conversion[as.character(Fuel_Type)], Fuel_Type),
         Seller_Type = ifelse(Seller_Type %in% names(seller_type_conversion), seller_type_conversion[as.character(Seller_Type)], Seller_Type),
         Transmission = ifelse(Transmission %in% names(transmission_conversion), transmission_conversion[as.character(Transmission)], Transmission))

# Show the conversion output of the specific attribute (Fuel_Type)
conversion_output <- converted_data$Fuel_Type
print(conversion_output)

#8 right
any(is.na(vehicles_data))
#print(ifelse(sum(is.na(vehicle_data)) > 0, paste("There are", sum(is.na(vehicle_data)), "missing values in the dataset."), "There are no missing values in the dataset."))

#9 right
# Find columns with missing values
columns_with_missing <- colSums(is.na(vehicles_data)) > 0

# Get the total missing values for each column
total_missing_values_count <- colSums(is.na(vehicles_data))

# Print the result
print(columns_with_missing)
print(total_missing_values_count)

#7
# Selecting the relevant columns
columns <- c("Car_Name", "Fuel_Type", "Seller_Type", "Transmission")

# Getting the combinations and their frequencies
combinations <- table(vehicle[, columns])

# Sort combinations in ascending order of frequency
ascending_order <- combinations[order(combinations)]

# Sort combinations in descending order of frequency
descending_order <- combinations[order(combinations, decreasing = TRUE)]

# Print combinations and their frequencies in ascending order
print(ascending_order)

# Print combinations and their frequencies in descending order
print(descending_order)

#11
# Check if dataset has duplicate rows
has_duplicates <- any(duplicated(vehicles_data))

# Remove duplicate rows if they exist
vehicle_data_unique <- vehicles_data[!duplicated(vehicles_data), ]

# Print message indicating if duplicate rows were removed or not
message <- c("No duplicate rows found.", "Duplicate rows have been removed.")[1 + has_duplicates]
print(message)

#13
# Calculate the current year
current_year <- as.numeric(format(Sys.Date(), "%Y"))

# Add a new field 'Age' based on the 'Year' column
vehicle_data <- transform(vehicle_data, Age = current_year - Year)

# Show the updated dataset with the 'Age' field
print(vehicle_data)

options(max.print = 999999)

#14
# Selecting specific columns
new_dataset <- vehicles_data[c("Car_Name", "Selling_Price", "Present_Price", "Kms_Driven")]

# Show the output of the new dataset
print(new_dataset)

#12
# Original attribute values
Fuel_Type <- c("Petrol", "Diesel", "CNG")
Seller_Type <- c("Dealer", "Individual")
Transmission <- c("Manual", "Automatic")

# Conversion mappings
fuel_type_mapping <- c("Petrol" = 0, "Diesel" = 1, "CNG" = 2)
seller_type_mapping <- c("Dealer" = 0, "Individual" = 1)
transmission_mapping <- c("Manual" = 0, "Automatic" = 1)

# Convert attribute values
converted_fuel_type <- fuel_type_mapping[Fuel_Type]
converted_seller_type <- seller_type_mapping[Seller_Type]
converted_transmission <- transmission_mapping[Transmission]

# Print the conversion outputs
print(converted_fuel_type)
print(converted_seller_type)
print(converted_transmission)

#15
# Read the dataset from the file
Vehicle <- read.csv("Vehicle.csv")

# Shuffle the rows randomly
shuffled_vehicle <- Vehicle[sample(nrow(Vehicle)), ]

# Show the output
shuffled_vehicle

#16
#Create a scatter plot
plot(
  Selling_Price ~ Present_Price, 
  data = vehicles_data, 
  pch = ifelse(vehicles_data$Transmission == 0, 0, 1), 
  col = ifelse(vehicles_data$Transmission == 0, "red", "blue"),
  xlab = "Present_Price",
  ylab = "Selling_Price",
  main = "Selling_Price vs Present_Price"
)

#By observing the output of the scatter plot, you can understand the relationship between Selling_Price and Present_Price based 
#on the color and shape of the points. Additionally, you can see how Transmission type influences this relationship. The plot 
#provides visual insights into any patterns or trends in the data, such as whether there is a positive or negative correlation
#between Selling_Price and Present_Price for different Transmission types.



##16
# Import the Vehicle dataset
data <- read.csv("Vehicle.csv")

# Create the scatter plot
ggplot(data, aes(x = Present_Price, y = Selling_Price, color = as.factor(Transmission))) +
  geom_point() +
  geom_point(shape = 2, color = "black") +
  labs(x = "Present_Price", y = "Selling_Price", title = "Selling_Price vs Present_Price (Transmission by Color)") +
  scale_color_manual(values = c("0" = "red", "1" = "blue"))


#17

install.packages("ggplot2")
library(ggplot2)

# Create a box plot
ggplot(Vehicle, aes(x = Transmission, y = Selling_Price, fill = Fuel_Type)) +
  geom_boxplot() +
  xlab("Transmission") +
  ylab("Selling_Price") +
  ggtitle("Box Plot of Selling_Price vs Transmission and Fuel_Type")

#18
library(ggplot2)

# Import the Vehicle dataset
data <- read.csv("Vehicle.csv")

# Select the columns of interest
selected_data <- data[, c("Selling_Price", "Kms_Driven")]

# Perform k-means clustering
k <- 4  # Number of clusters
kmeans_result <- kmeans(selected_data, centers = k, nstart = 25)

# Add cluster labels to the dataset
selected_data$cluster <- as.factor(kmeans_result$cluster)

# Create the scatter plot with cluster coloring
ggplot(selected_data, aes(x = Kms_Driven, y = Selling_Price, color = cluster)) +
  geom_point() +
  labs(x = "Kms_Driven", y = "Selling_Price", title = "Selling_Price vs Kms_Driven (Clustered)") +
  scale_color_manual(values = c("red", "blue", "green", "purple"))


#19
# Create a scatter plot
plot(Vehicle$Present_Price, Vehicle$Selling_Price,
     xlab = "Present_Price", ylab = "Selling_Price",
     main = "Scatter Plot of Selling_Price vs Present_Price")

# Perform hierarchical clustering
dist_matrix <- dist(Vehicle[, c("Present_Price", "Selling_Price")])
hclust_result <- hclust(dist_matrix, method = "ward.D2", members = NULL)
clusters <- cutree(hclust_result, k = 3)

# Define colors for the clusters
cluster_colors <- c("yellow", "red", "blue")

# Recreate the scatter plot with color-coded clusters
plot(Vehicle$Present_Price, Vehicle$Selling_Price,
     col = cluster_colors[clusters],
     xlab = "Present_Price", ylab = "Selling_Price",
     main = "Scatter Plot of Selling_Price vs Present_Price (Clustered)")

#20
# Add 'Age' field based on 'Year'
Plot_Data$Age <- 2023 - Plot_Data$Year 
# Select the fields for the barplot
fields <- c("Age", "Year", "Transmission", "Seller_Type", "Fuel_Type", "Owner")
# Create a barplot
barplot_data <- data.frame(table(Plot_Data[, fields])) 
# Rename the columns of the barplot_data
colnames(barplot_data) <- c("Field", "Value", "Frequency")
# Create a color palette based on unique values in the "Value" column
color_palette <- scales::hue_pal()(length(unique(barplot_data$Value)))
# Create a barplot with labels, titles, and colors
ggplot(barplot_data, aes(x = Field, y = Frequency, fill = Value)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(x = "Fields", y = "Frequency", fill = "Value") +
  ggtitle("Barplot: Frequency of Fields") +
  scale_fill_manual(values = color_palette) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


#21
dataa <- vehicles_vehicledata
dataa$Year <- as.numeric(dataa$Year)
dataa$Transmission <- as.numeric(dataa$Transmission)
dataa$Seller_Type <- as.numeric(dataa$Seller_Type)
dataa$Fuel_Type <- as.numeric(dataa$Fuel_Type)
dataa$Owner <- as.numeric(dataa$Owner)

# Calculate correlation matrix
correlation_matrix <- cor(dataa[, -c(1, 14)], use = "pairwise.complete.obs")

# Create the correlation plot
corrplot(correlation_matrix, method = "color", type = "lower", tl.col = "black")


#22
vehicles_vehicledata$Selling_Price <- as.numeric(vehicles_vehicledata$Selling_Price)
vehicles_vehicledata$Kms_Driven <- as.numeric(vehicles_vehicledata$Kms_Driven)

# Select the variables of interest
variables <- c("Selling_Price", "Kms_Driven")
data_subset <- vehicles_vehicledata[, variables]

# Perform DBSCAN clustering
library(dbscan)
result_dbscan <- dbscan(data_subset, eps = 3, MinPts = 5)

# Extract cluster labels
cluster_labels <- result_dbscan$cluster

# Create the scatter plot with coloring uster
plot(data_subset$Selling_Price, data_subset$Kms_Driven, pch = 16, col = cluster_labels,
     xlab = "Selling_Price", ylab = "Kms_Driven", main = "Scatter Plot with DBSCAN Clustering")

# For legend
legend("topright", legend = unique(cluster_labels), pch = 16, col = unique(cluster_labels), title = "Cluster")